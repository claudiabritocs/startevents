<?php $__env->startSection('title', 'Start Eventos'); ?>

<?php $__env->startSection('content'); ?>

<div id="search-container" class="col-md-12">
  <h1>Encontre seu rolê</h1>
  <form action="/" method="GET">
    <input 
    type="text"
    id="search"
    name="search"
    class="form-control"
    placeholder="Procurar">
  </form>
</div>

<div id="events-container" class="col-md-12">
  <?php if($search): ?>
    <h2>Você está buscando por: <strong><?php echo e($search); ?></strong></h2>
  <?php else: ?>
    <h2>Próximos Eventos</h2>
  <?php endif; ?>
  <p class="subtitle">O que vem por aí...</p>
  <div id="cards-container" class="row">
    <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card col-md-3">
      <img src="/img/events/<?php echo e($event->image); ?>" alt="<?php echo e($event->title); ?>">
      <div class="card-body">
        <h5 class="card-title"><?php echo e($event->title); ?></h5>
        <p class="card-date"><?php echo e(date('d/m/Y', strtotime($event->date))); ?></p>
        <p class="card-participants"><?php echo e(count($event->users)); ?> Participantes</p>
        <a href="/events/<?php echo e($event->id); ?>" class="btn btn-primary">Saber mais</a>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if(count($events) == 0 && $search): ?>
      <p>Não encontramos nenhum evento com <?php echo e($search); ?>. Que tal montar um? <a href="/events/create">Criar Evento!</a></p>
    <?php elseif(count($events) == 0): ?>
      <p>Ainda não temos nenhum evento... Bora criar um?</p>
    <?php endif; ?>
  </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ducou\startevents\resources\views/welcome.blade.php ENDPATH**/ ?>