<h1>Esta é a página de contato.</h1>

<a href="/">Voltar para Home</a><?php /**PATH C:\Users\ducou\startevents\resources\views/contact.blade.php ENDPATH**/ ?>