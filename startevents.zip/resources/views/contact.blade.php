@extends('layouts.main')

@section('title', 'Produtos')

@section('content')

<h1>Esta é a página de contato.</h1>

<a href="/">Voltar para Home</a>

@endsection